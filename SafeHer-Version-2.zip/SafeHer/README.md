# SafeHer Android Prototype

SafeHer is a prototype women-safety app concept for South Africa.

## Included
- Home dashboard
- 3-second emergency confirmation
- Trusted contacts saved locally on the phone
- Emergency/safety SMS attempt
- Current-location sharing
- Safe Trip start/end and check-in
- Nearby police, hospitals and GBV support search through the phone's map app
- Emergency dialer shortcuts (10111 and 112)

## Important limitations
This is a prototype, not a certified emergency-response system. It does not provide guaranteed live monitoring, dispatch police, or guarantee delivery of SMS/location data. Background tracking, secure cloud accounts, real-time contact dashboards, offline/low-signal fallback, abuse-resistant account security, and production testing still need to be implemented before public release.

## Build
Open the `SafeHer` folder in Android Studio on Android Studio-compatible Windows, macOS, or Linux. The project uses a standard Android Gradle configuration and no external UI libraries.

If you only have an Android phone, use a cloud development environment or an Android-capable build service to compile the project. Never upload real users' contact/location data to an untrusted service.

## Product roadmap
1. Secure account + trusted-contact authentication
2. Real-time backend and encrypted location sharing
3. Foreground/background location service with clear consent
4. Reliable emergency workflow and delivery receipts
5. Offline/SMS fallback and low-battery handling
6. Verified South African GBV resources and partnerships
7. Privacy/security review and independent safety testing
8. Pilot with a small group before public launch
