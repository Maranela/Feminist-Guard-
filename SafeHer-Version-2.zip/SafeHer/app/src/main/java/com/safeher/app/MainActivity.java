package com.safeher.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.telephony.SmsManager;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    private LinearLayout content;
    private LocationManager locationManager;
    private Location lastLocation;
    private boolean tripActive = false;
    private String destination = "";
    private final ArrayList<Contact> contacts = new ArrayList<>();
    private SharedPreferences prefs;
    private static final int REQ_LOCATION = 10, REQ_SMS = 11;
    private final int purple = Color.rgb(91,33,182), pink = Color.rgb(236,72,153), red = Color.rgb(220,38,38);
    private final int bg = Color.rgb(248,247,252), text = Color.rgb(32,26,43), muted = Color.rgb(105,98,116);

    static class Contact {
        String name, phone;
        Contact(String n, String p) { name=n; phone=p; }
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("safeher", MODE_PRIVATE);
        locationManager = (LocationManager)getSystemService(LOCATION_SERVICE);
        loadContacts();
        showHome();
    }

    private TextView tv(String s, int sp) {
        TextView v = new TextView(this); v.setText(s); v.setTextSize(sp); v.setTextColor(text);
        v.setPadding(8,12,8,12); return v;
    }
    private Button btn(String s, int color) {
        Button b = new Button(this); b.setText(s); b.setTextColor(Color.WHITE); b.setTextSize(15); b.setAllCaps(false);
        b.setBackgroundColor(color); b.setPadding(8,4,8,4); return b;
    }
    private void base(String heading) {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(bg);
        LinearLayout bar = new LinearLayout(this); bar.setGravity(Gravity.CENTER_VERTICAL); bar.setPadding(12,8,12,4);
        TextView title=tv(heading,23); title.setTypeface(null,1); bar.addView(title,new LinearLayout.LayoutParams(0,70,1));
        Button home=btn("Home",purple); home.setOnClickListener(v->showHome()); bar.addView(home,new LinearLayout.LayoutParams(100,60)); root.addView(bar);
        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(18,6,18,12);
        ScrollView scroll=new ScrollView(this); scroll.addView(content); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout nav=new LinearLayout(this); nav.setPadding(6,6,6,6);
        String[] names={"Home","Safe Trip","Contacts","Safe Places"};
        for(String n:names){ Button x=btn(n,Color.DKGRAY); x.setOnClickListener(v->{if(n.equals("Home"))showHome();else if(n.equals("Safe Trip"))showTrip();else if(n.equals("Contacts"))showContacts();else showPlaces();}); nav.addView(x,new LinearLayout.LayoutParams(0,62,1)); }
        root.addView(nav); setContentView(root);
    }
    private void showHome() {
        base("SafeHer");
        content.addView(tv("You are not alone. We are here for you.",18));
        TextView tip=tv("Your safety circle can be ready before you leave home.",14); tip.setTextColor(muted); content.addView(tip);
        Button trip=btn("🛡  Start Safe Trip",purple); content.addView(trip); trip.setOnClickListener(v->showTrip());
        Button emergency=btn("🚨  EMERGENCY — press and hold 3 seconds",red); LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(-1,115); ep.setMargins(0,18,0,10); content.addView(emergency,ep);
        emergency.setOnClickListener(v->Toast.makeText(this,"Keep holding the button for 3 seconds.",Toast.LENGTH_SHORT).show());
        emergency.setOnLongClickListener(v->{emergencyCountdown(); return true;});
        Button unsafe=btn("I'm Feeling Unsafe",pink); content.addView(unsafe); unsafe.setOnClickListener(v->unsafeMode());
        content.addView(tv("Quick access",18));
        Button contactsBtn=btn("👥  Trusted Contacts",purple); content.addView(contactsBtn); contactsBtn.setOnClickListener(v->showContacts());
        Button places=btn("📍  Safe Places",purple); content.addView(places); places.setOnClickListener(v->showPlaces());
        TextView disclaimer=tv("Safety note: SafeHer is a support tool, not a guarantee of safety. In immediate danger, contact emergency services.",13); disclaimer.setTextColor(muted); content.addView(disclaimer);
    }
    private void showTrip() {
        base("Safe Trip");
        content.addView(tv(tripActive?"Your Safe Trip is active.":"Plan a trip and choose who should know where you're going.",17));
        EditText d=new EditText(this); d.setHint("Destination"); d.setText(destination); d.setSingleLine(true); content.addView(d);
        Button start=btn(tripActive?"End Safe Trip":"Start Safe Trip",purple); content.addView(start);
        TextView status=tv(tripActive?"🟢 Monitoring your current phone location when available.":"",14); status.setTextColor(muted); content.addView(status);
        start.setOnClickListener(v->{
            if(!tripActive){ destination=d.getText().toString().trim(); if(destination.isEmpty()){d.setError("Enter a destination");return;} tripActive=true; requestLocation(); sendTripMessage(); status.setText("🟢 Trip active. Your trusted contacts can be notified."); start.setText("End Safe Trip"); }
            else { tripActive=false; stopLocation(); status.setText("Trip ended. Stay safe ❤️"); start.setText("Start Safe Trip"); }
        });
        Button share=btn("Share my current location",pink); content.addView(share); share.setOnClickListener(v->shareLocation());
        Button check=btn("I'm safe — check in",purple); content.addView(check); check.setOnClickListener(v->sendSmsToContacts("SafeHer check-in: I'm safe. I am currently on my Safe Trip to " + destination + "."));
    }
    private void showContacts() {
        base("Trusted Contacts"); content.addView(tv("Add people you trust. They can receive emergency or safety messages.",16));
        EditText name=new EditText(this); name.setHint("Name"); content.addView(name);
        EditText phone=new EditText(this); phone.setHint("Phone number"); phone.setInputType(InputType.TYPE_CLASS_PHONE); content.addView(phone);
        Button add=btn("+ Add Contact",purple); content.addView(add);
        LinearLayout list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); content.addView(list); renderContacts(list);
        add.setOnClickListener(v->{String n=name.getText().toString().trim(),p=phone.getText().toString().trim(); if(n.isEmpty()||p.isEmpty()){Toast.makeText(this,"Enter both name and phone number",Toast.LENGTH_SHORT).show();return;} contacts.add(new Contact(n,p)); saveContacts(); name.setText(""); phone.setText(""); renderContacts(list);});
    }
    private void renderContacts(LinearLayout list){list.removeAllViews(); if(contacts.isEmpty()){TextView e=tv("No trusted contacts yet. Add at least one before relying on emergency messaging.",14);e.setTextColor(muted);list.addView(e);return;} for(int i=0;i<contacts.size();i++){final int index=i; Contact c=contacts.get(i); LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);TextView t=tv("👤  "+c.name+"\n     "+c.phone,16);row.addView(t,new LinearLayout.LayoutParams(0,78,1));Button del=btn("Remove",red);row.addView(del,new LinearLayout.LayoutParams(100,60));del.setOnClickListener(v->{contacts.remove(index);saveContacts();renderContacts(list);});list.addView(row);}}
    private void loadContacts(){contacts.clear();String raw=prefs.getString("contacts","");if(!raw.isEmpty())for(String item:raw.split(";;")){String[] a=item.split("\\|",2);if(a.length==2)contacts.add(new Contact(a[0],a[1]));}}
    private void saveContacts(){StringBuilder b=new StringBuilder();for(Contact c:contacts){if(b.length()>0)b.append(";;");b.append(c.name.replace("|","")).append("|").append(c.phone.replace("|",""));}prefs.edit().putString("contacts",b.toString()).apply();}
    private void showPlaces(){base("Safe Places");content.addView(tv("Find nearby places where you can get help. Your map app will show current results.",16));Button p=btn("🚓  Police stations",purple);content.addView(p);p.setOnClickListener(v->mapSearch("police station"));Button h=btn("🏥  Hospitals & clinics",pink);content.addView(h);h.setOnClickListener(v->mapSearch("hospital"));Button s=btn("🏠  GBV support & shelters",purple);content.addView(s);s.setOnClickListener(v->mapSearch("GBV support shelter South Africa"));}
    private void mapSearch(String q){try{startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q="+Uri.encode(q))));}catch(Exception e){startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.google.com/maps/search/?api=1&query="+Uri.encode(q))));}}
    private void requestLocation(){if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},REQ_LOCATION);}else startLocation();}
    private void startLocation(){try{locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,3000,5,new LocationListener(){public void onLocationChanged(Location l){lastLocation=l;}public void onProviderEnabled(String p){}public void onProviderDisabled(String p){}public void onStatusChanged(String p,int s,Bundle b){}});}catch(SecurityException e){Toast.makeText(this,"Location permission is required.",Toast.LENGTH_LONG).show();}}
    private void stopLocation(){try{locationManager.removeUpdates(new LocationListener(){public void onLocationChanged(Location l){}public void onProviderEnabled(String p){}public void onProviderDisabled(String p){}public void onStatusChanged(String p,int s,Bundle b){}});}catch(Exception ignored){}}
    private String locationText(){if(lastLocation==null)return "Location not available yet. Please open Location and try again.";return "https://maps.google.com/?q="+lastLocation.getLatitude()+","+lastLocation.getLongitude();}
    private void emergencyCountdown(){final AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Emergency alert").setMessage("Preparing your emergency alert…").setNegativeButton("CANCEL",null).create();dialog.show();final Handler h=new Handler();final int[] n={3};Runnable r=new Runnable(){public void run(){if(!dialog.isShowing())return;if(n[0]>0){dialog.setMessage("Emergency alert in "+n[0]+"…\nTap CANCEL if this was accidental.");n[0]--;h.postDelayed(this,1000);}else{dialog.dismiss();emergencyAlert();}}};h.post(r);}
    private void emergencyAlert(){requestLocation();String msg="SAFEHER EMERGENCY ALERT. I may need help. Please contact me and use this location: "+locationText();sendSmsToContacts(msg);new AlertDialog.Builder(this).setTitle("Emergency activated").setMessage("SafeHer attempted to notify your trusted contacts. SMS/location delivery depends on phone permissions, network and carrier availability.").setPositiveButton("Call 10111",(d,w)->dial("10111")).setNeutralButton("Call 112",(d,w)->dial("112")).setNegativeButton("Close",null).show();}
    private void unsafeMode(){requestLocation();sendSmsToContacts("SAFEHER: I am feeling unsafe. Please check on me. My location: "+locationText());Toast.makeText(this,"Safety message prepared/sent where possible.",Toast.LENGTH_LONG).show();}
    private void shareLocation(){String msg="SafeHer: My current location is "+locationText();Intent send=new Intent(Intent.ACTION_SENDTO);send.setData(Uri.parse("smsto:"));send.putExtra("sms_body",msg);try{startActivity(send);}catch(Exception e){Toast.makeText(this,msg,Toast.LENGTH_LONG).show();}}
    private void sendTripMessage(){sendSmsToContacts("SafeHer: I started a Safe Trip to "+destination+". I will check in when I arrive. Current location: "+locationText());}
    private void sendSmsToContacts(String msg){if(contacts.isEmpty()){Toast.makeText(this,"Add trusted contacts first.",Toast.LENGTH_LONG).show();return;}if(checkSelfPermission(Manifest.permission.SEND_SMS)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.SEND_SMS},REQ_SMS);return;}try{SmsManager sm=SmsManager.getDefault();for(Contact c:contacts)sm.sendTextMessage(c.phone,null,msg,null,null);}catch(Exception e){Toast.makeText(this,"SMS could not be sent. Use the Share option instead.",Toast.LENGTH_LONG).show();}}
    private void dial(String n){try{startActivity(new Intent(Intent.ACTION_DIAL,Uri.parse("tel:"+n)));}catch(Exception e){Toast.makeText(this,"Unable to open phone dialer",Toast.LENGTH_SHORT).show();}}
    @Override protected void onDestroy(){super.onDestroy();try{locationManager.removeUpdates(new LocationListener(){public void onLocationChanged(Location l){}public void onProviderEnabled(String p){}public void onProviderDisabled(String p){}public void onStatusChanged(String p,int s,Bundle b){}});}catch(Exception ignored){}}
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==REQ_LOCATION&&g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)startLocation();else if(r==REQ_SMS&&g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)Toast.makeText(this,"SMS permission granted. Trigger the alert again to send it.",Toast.LENGTH_SHORT).show();}
}
